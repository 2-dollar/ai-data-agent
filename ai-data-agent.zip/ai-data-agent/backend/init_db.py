import sqlite3
import pandas as pd
import random
from datetime import datetime, timedelta

conn = sqlite3.connect('sales.db')

rows = []

channels = [
    'TikTok',
    'Google',
    'Facebook',
    'Xiaohongshu',
]

for i in range(100):
    rows.append({
        'order_date': (
            datetime.now() - timedelta(days=i)
        ).strftime('%Y-%m-%d'),
        'channel': random.choice(channels),
        'revenue': random.randint(1000, 10000),
        'cost': random.randint(500, 5000),
        'users': random.randint(10, 300),
    })

df = pd.DataFrame(rows)

df.to_sql('sales', conn, if_exists='replace', index=False)

print('数据库初始化完成')
