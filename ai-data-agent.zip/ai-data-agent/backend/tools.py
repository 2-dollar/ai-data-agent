import matplotlib.pyplot as plt
import uuid

def generate_chart(df, x_col, y_col):
    filename = f"chart_{uuid.uuid4()}.png"

    plt.figure(figsize=(8, 4))
    plt.plot(df[x_col], df[y_col])
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(filename)

    return filename
