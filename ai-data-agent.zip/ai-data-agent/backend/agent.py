from openai import OpenAI
from db import run_sql
from tools import generate_chart

client = OpenAI(api_key="YOUR_OPENAI_API_KEY")

SYSTEM_PROMPT = """
你是一个专业的数据分析 Agent。

你的职责：
1. 根据用户问题生成 SQL
2. 分析数据
3. 给出业务洞察
4. 自动推荐图表
5. 输出最终报告
"""

def generate_sql(user_question):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"""
数据库表：sales
字段：
- order_date
- channel
- revenue
- cost
- users

请根据问题生成 SQL：
{user_question}

只返回 SQL。
""",
            },
        ],
    )

    return response.choices[0].message.content

def analyze_data(question, df):
    data_preview = df.head(20).to_markdown()

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "你是高级商业数据分析师"},
            {
                "role": "user",
                "content": f"""
问题：
{question}

数据：
{data_preview}

请输出：
1. 数据结论
2. 趋势分析
3. 异常点
4. 优化建议
""",
            },
        ],
    )

    return response.choices[0].message.content

def run_agent(question):
    sql = generate_sql(question)

    df = run_sql(sql)

    analysis = analyze_data(question, df)

    chart_path = None

    if len(df.columns) >= 2:
        chart_path = generate_chart(
            df,
            df.columns[0],
            df.columns[1],
        )

    return {
        "sql": sql,
        "rows": df.to_dict(orient="records"),
        "analysis": analysis,
        "chart": chart_path,
    }
