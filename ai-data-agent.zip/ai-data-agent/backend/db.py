from sqlalchemy import create_engine
import pandas as pd

DATABASE_URL = "sqlite:///sales.db"

engine = create_engine(DATABASE_URL)

def run_sql(query: str):
    df = pd.read_sql(query, engine)
    return df
