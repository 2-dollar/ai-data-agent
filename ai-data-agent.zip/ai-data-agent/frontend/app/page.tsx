'use client'

import { useState } from 'react'

export default function Home() {
  const [question, setQuestion] = useState('')
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  async function askAgent() {
    setLoading(true)

    const res = await fetch('http://localhost:8000/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ question }),
    })

    const data = await res.json()
    setResult(data)

    setLoading(false)
  }

  return (
    <div className="p-10 max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold mb-6">
        AI Data Analysis Agent
      </h1>

      <textarea
        className="w-full border p-4 rounded-lg"
        rows={4}
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="最近7天哪个渠道ROI下降最多？"
      />

      <button
        onClick={askAgent}
        className="mt-4 bg-black text-white px-6 py-3 rounded-lg"
      >
        {loading ? '分析中...' : '开始分析'}
      </button>

      {result && (
        <div className="mt-10 space-y-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">生成 SQL</h2>
            <pre className="bg-gray-100 p-4 rounded-lg overflow-auto">
              {result.sql}
            </pre>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-2">分析结果</h2>
            <div className="bg-gray-100 p-4 rounded-lg whitespace-pre-wrap">
              {result.analysis}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
