# AI Data Analysis Agent

## 启动后端

```bash
cd backend
pip install -r requirements.txt
python init_db.py
uvicorn main:app --reload
```

## 启动前端

```bash
cd frontend
npm install
npm run dev
```

## 功能

- Text-to-SQL
- AI 自动分析
- 图表生成
- FastAPI
- Next.js
- GPT-4o Agent
